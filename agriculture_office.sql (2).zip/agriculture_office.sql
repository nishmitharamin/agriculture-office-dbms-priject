-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2022 at 05:53 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agriculture_office`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(11) NOT NULL,
  `bank_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `bank_name`) VALUES
(600001, 'NITW Bank'),
(600002, 'SBI'),
(600003, 'Central Bank'),
(600004, 'Canara Bank'),
(600005, 'Bank of India'),
(600006, 'Bank of Mizo'),
(600007, 'Dena Bank'),
(600008, 'Kerala Bank');

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `b_id` int(11) NOT NULL,
  `buyer_name` varchar(20) DEFAULT NULL,
  `farm_no` int(11) DEFAULT NULL,
  `crop_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`b_id`, `buyer_name`, `farm_no`, `crop_name`) VALUES
(400001, 'Raghav', 1, 'Jowar'),
(400002, 'Ashutosh', 2, 'Toor'),
(400003, 'Deepak', 3, 'Bajra'),
(400004, 'Krishnanshu', 4, 'Rice'),
(400005, 'Raghvandra', 5, 'Maize'),
(400006, 'Chirantan', 6, 'Turmeric'),
(400007, 'Shubhank', 7, 'Wheat'),
(400008, 'Avishek', 8, 'Pepper');

-- --------------------------------------------------------

--
-- Table structure for table `crops`
--

CREATE TABLE `crops` (
  `name_` varchar(20) NOT NULL,
  `crop_type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crops`
--

INSERT INTO `crops` (`name_`, `crop_type`) VALUES
('Arhar', 'Pulses'),
('Bajra', 'Cereals'),
('Jowar', 'Cereals'),
('Maize', 'Cereals'),
('Pepper', 'Spices'),
('Rice', 'Cereals'),
('Toor', 'Pulses'),
('Turmeric', 'Spices'),
('Wheat', 'Cereals');

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `farmer_id` int(11) NOT NULL,
  `farmer_name` varchar(20) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `contact` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`farmer_id`, `farmer_name`, `gender`, `contact`) VALUES
(900001, 'Dijeet Singh', 'M', 2147483647),
(900002, 'Shivshankar Tambe', 'M', 817856790),
(900003, 'Harpreet Sahu', 'M', 2147483647),
(900004, 'Meiyan Dumphut', 'M', 2147483647),
(900005, 'Ramadhir Singh', 'M', 2147483647),
(900006, 'Ashok Jadhar', 'M', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `fields`
--

CREATE TABLE `fields` (
  `farm_no` int(11) NOT NULL,
  `area` int(11) DEFAULT NULL,
  `farmer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fields`
--

INSERT INTO `fields` (`farm_no`, `area`, `farmer_id`) VALUES
(1, 2000, 900001),
(2, 1000, 900002),
(3, 2400, 900003),
(4, 1800, 900004),
(5, 3000, 900001),
(6, 2200, 900002),
(7, 4000, 900005),
(8, 3200, 900006);

-- --------------------------------------------------------

--
-- Table structure for table `inputs`
--

CREATE TABLE `inputs` (
  `pesticide_fertiliser_name` varchar(20) DEFAULT NULL,
  `sup_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inputs`
--

INSERT INTO `inputs` (`pesticide_fertiliser_name`, `sup_id`, `price`) VALUES
('Grow', 400001, 50),
('Vermi Compost', 400002, 45),
('Coco Peat', 400003, 35),
('Grow', 400004, 50),
('Ready To Pot', 400005, 40),
('Organic Fertiliser', 400006, 65),
('Vermi Compost', 400007, 45),
('Flower Mix', 400008, 95);

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL,
  `amt` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `farm_no` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `amt`, `bank_id`, `farm_no`) VALUES
(700001, 15000, 600006, 1),
(700002, 30000, 600004, 2),
(700003, 5000, 600002, 3),
(700004, 10000, 600001, 4),
(700005, 20000, 600003, 5),
(700006, 40000, 600008, 6),
(700007, 25000, 600005, 7),
(700008, 35000, 600007, 8);

-- --------------------------------------------------------

--
-- Table structure for table `supply`
--

CREATE TABLE `supply` (
  `sup_id` int(11) NOT NULL,
  `sup_name` varchar(20) DEFAULT NULL,
  `farm_no` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supply`
--

INSERT INTO `supply` (`sup_id`, `sup_name`, `farm_no`) VALUES
(400001, 'Ashish', 1),
(400002, 'Rahul', 3),
(400003, 'Ranjan', 7),
(400004, 'Ashish', 5),
(400005, 'Raushan', 4),
(400006, 'Prateek', 6),
(400007, 'Rahul', 2),
(400008, 'Farhan', 8);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `warehouse_id` int(11) NOT NULL,
  `owner_` varchar(20) DEFAULT NULL,
  `b_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`warehouse_id`, `owner_`, `b_id`) VALUES
(500001, 'Deepak', 400001),
(500002, 'Jamal', 400002),
(500003, 'Rishab', 400003),
(500004, 'Farhan', 400008),
(500005, 'Naman', 400007),
(500006, 'Devansh', 400005),
(500007, 'Tarun', 400004),
(500008, 'Aniket', 400006);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`b_id`),
  ADD KEY `farm_no` (`farm_no`),
  ADD KEY `crop_name` (`crop_name`);

--
-- Indexes for table `crops`
--
ALTER TABLE `crops`
  ADD PRIMARY KEY (`name_`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`farmer_id`);

--
-- Indexes for table `fields`
--
ALTER TABLE `fields`
  ADD PRIMARY KEY (`farm_no`),
  ADD KEY `farmer_id` (`farmer_id`);

--
-- Indexes for table `inputs`
--
ALTER TABLE `inputs`
  ADD KEY `sup_id` (`sup_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`loan_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `farm_no` (`farm_no`);

--
-- Indexes for table `supply`
--
ALTER TABLE `supply`
  ADD PRIMARY KEY (`sup_id`),
  ADD KEY `farm_no` (`farm_no`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`warehouse_id`),
  ADD KEY `b_id` (`b_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buyer`
--
ALTER TABLE `buyer`
  ADD CONSTRAINT `buyer_ibfk_1` FOREIGN KEY (`farm_no`) REFERENCES `fields` (`farm_no`),
  ADD CONSTRAINT `crop_name` FOREIGN KEY (`crop_name`) REFERENCES `crops` (`name_`);

--
-- Constraints for table `fields`
--
ALTER TABLE `fields`
  ADD CONSTRAINT `fields_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmer` (`farmer_id`);

--
-- Constraints for table `inputs`
--
ALTER TABLE `inputs`
  ADD CONSTRAINT `inputs_ibfk_1` FOREIGN KEY (`sup_id`) REFERENCES `supply` (`sup_id`);

--
-- Constraints for table `loan`
--
ALTER TABLE `loan`
  ADD CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`bank_id`),
  ADD CONSTRAINT `loan_ibfk_2` FOREIGN KEY (`farm_no`) REFERENCES `fields` (`farm_no`);

--
-- Constraints for table `supply`
--
ALTER TABLE `supply`
  ADD CONSTRAINT `farm_no` FOREIGN KEY (`farm_no`) REFERENCES `fields` (`farm_no`);

--
-- Constraints for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD CONSTRAINT `warehouse_ibfk_1` FOREIGN KEY (`b_id`) REFERENCES `buyer` (`b_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
